library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity rom is
    port(
        dir: in std_logic_vector(5 downto 0); -- edopresente + entradas
        data: out std_logic_vector(6 downto 0) --  Liga + Salida
    );
end rom;

architecture Behavioral of rom is
    type mem is array (0 to 63) of std_logic_vector(6 downto 0);
    signal internal_mem: mem;

    begin
        -- Liga + Salida
        --S0
        internal_mem(0) <= "000" & "0011";
        internal_mem(1) <= "000" & "0011";
        internal_mem(2) <= "000" & "0011";
        internal_mem(3) <= "000" & "0011";
        internal_mem(4) <= "001" & "0011";
        internal_mem(5) <= "001" & "0011";
        internal_mem(6) <= "001" & "0011";
        internal_mem(7) <= "001" & "0011";
        --S1
        internal_mem(8) <= "001" & "1011";
        internal_mem(9) <= "010" & "1011";
        internal_mem(10) <= "001" & "1011";
        internal_mem(11) <= "010" & "1011";
        internal_mem(12) <= "001" & "1011";
        internal_mem(13) <= "010" & "1011";
        internal_mem(14) <= "001" & "1011";
        internal_mem(15) <= "010" & "1011";
        --S2
        internal_mem(16) <= "010" & "0011";
        internal_mem(17) <= "010" & "0011";
        internal_mem(18) <= "001" & "0011";
        internal_mem(19) <= "010" & "0010";
        internal_mem(20) <= "010" & "0011";
        internal_mem(21) <= "010" & "0011";
        internal_mem(22) <= "001" & "0011";
        internal_mem(23) <= "011" & "0010";
        --S3
        internal_mem(24) <= "011" & "0111";
        internal_mem(25) <= "100" & "0111";
        internal_mem(26) <= "011" & "0111";
        internal_mem(27) <= "100" & "0111";
        internal_mem(28) <= "011" & "0111";
        internal_mem(29) <= "100" & "0111";
        internal_mem(30) <= "011" & "0111";
        internal_mem(31) <= "100" & "0111";
        --S4
        internal_mem(32) <= "101" & "0111";
        internal_mem(33) <= "101" & "0111";
        internal_mem(34) <= "100" & "0110";
        internal_mem(35) <= "100" & "0110";
        internal_mem(36) <= "101" & "0111";
        internal_mem(37) <= "101" & "0111";
        internal_mem(38) <= "101" & "0110";
        internal_mem(39) <= "101" & "0110";
        --S5
        internal_mem(40) <= "101" & "0001";
        internal_mem(41) <= "101" & "0001";
        internal_mem(42) <= "101" & "0001";
        internal_mem(43) <= "101" & "0001";

        internal_mem(44) <= "000" & "0001";
        internal_mem(45) <= "000" & "0001";
        internal_mem(46) <= "000" & "0001";
        internal_mem(47) <= "000" & "0001";

        process(dir)
            begin
                data <= internal_mem(conv_integer(unsigned(dir)));
        end process;
end Behavioral;