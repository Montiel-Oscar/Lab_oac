library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity divisor_datos is
    Port (
        data    : in  std_logic_vector(12 downto 0);
        prueba  : out std_logic_vector(1 downto 0);
        VF      : out std_logic;
        MI      : out std_logic_vector(1 downto 0);
        liga    : out std_logic_vector(3 downto 0);
        salidas : out std_logic_vector(3 downto 0)
    );
end divisor_datos;

architecture Behavioral of divisor_datos is
begin
    -- Prueba[12:11], VF[10], MI[9:8], Liga[7:4], Salidas[3:0]
    prueba  <= data(12 downto 11);
    VF      <= data(10);
    MI      <= data(9 downto 8);
    liga    <= data(7 downto 4);
    salidas <= data(3 downto 0);
end Behavioral;