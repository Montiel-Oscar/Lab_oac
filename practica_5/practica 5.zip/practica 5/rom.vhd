library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.STD_LOGIC_ARITH.ALL;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

entity rom is
	Port ( direccion : in std_logic_vector (2 downto 0);
				data : out std_logic_vector (13 downto 0)
	);
end rom;

architecture Behavioral of rom is

type mem is array (0 to 7) of std_logic_vector (13 downto 0);
signal internal_mem: mem;

begin
	
	--  prueba & VF & liga & SF & SV
	
	internal_mem(0) <= "10" & "1" & "000" & "1010" & "0010";	
	internal_mem(1) <= "00" & "1" & "000" & "0111" & "1111";	
	internal_mem(2) <= "01" & "0" & "100" & "1011" & "1011";
	internal_mem(3) <= "11" & "0" & "001" & "0001" & "0001";	
	internal_mem(4) <= "11" & "0" & "001" & "0010" & "0010";	
	internal_mem(5) <= "11" & "0" & "001" & "0011" & "0011";
	internal_mem(6) <= "11" & "0" & "001" & "0011" & "0011";	
	internal_mem(7) <= "11" & "0" & "001" & "0011" & "0011";	
	 process(direccion)
	 begin
		data <= internal_mem(conv_integer(unsigned(direccion)));
		
	end process;
	
end Behavioral;